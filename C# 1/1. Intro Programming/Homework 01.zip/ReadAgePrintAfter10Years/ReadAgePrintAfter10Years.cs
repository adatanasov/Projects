﻿using System;

class ReadAgePrintAfter10Years
{
    static void Main()
    {
        Console.WriteLine("Your current age is...");
        int i = int.Parse(Console.ReadLine());
        Console.WriteLine("Yours age in 10 years will be " + (i+10));
    }
}

