﻿using System;

class PrintSquareOf12345
{
    static void Main()
    {
        Console.WriteLine(12345*12345);
    }
}

